<?php
return [
    'admin' => 'Администратор',
    'manager' => 'Менеджер',
    'master' => 'Мастер',
    'hairdresser' => 'Парикмахер',
    'cosmetologist' => 'Косметолог',
    'nailmaster' => 'Мастер маникюра/педикюра',
    'makeup' => 'Визажист',
    'browlash' => 'Бровист / Лэшмейкер',
    'massage' => 'Массажист',
    'stylist' => 'Стилист / Колорист',
    'barber' => 'Барбер',
    'senior_barber' => 'Старший барбер',
    'shaving' => 'Мастер по бритью',
    'intern' => 'Стажёр',
    'seller' => 'Продавец',
    'storekeeper' => 'Кладовщик',
]; 