<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Clients\ClientType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ClientTypeController extends Controller
{
    public function index(Request $request)
    {
        $currentProjectId = auth()->user()->project_id;
        $query = ClientType::where(function($q) use ($currentProjectId) {
            $q->where('project_id', $currentProjectId)
              ->orWhere('is_global', true);
        })->orderBy('created_at', 'desc');

        if ($request->has('search') && $request->search !== '') {
            $search = $request->search;
            $query->where('name', 'like', "%$search%");
        }

        if ($request->ajax()) {
            $clientTypes = $query->get();
            
            // Добавляем переведенные названия для каждого типа клиента
            foreach ($clientTypes as $clientType) {
                $clientType->translated_name = $clientType->translated_name;
            }
            
            return response()->json([
                'data' => $clientTypes,
                'meta' => [
                    'current_page' => 1,
                    'last_page' => 1,
                    'per_page' => count($clientTypes),
                    'total' => count($clientTypes),
                ],
            ]);
        }

        $clientTypes = $query->get();
        
        // Добавляем переведенные названия для каждого типа клиента
        foreach ($clientTypes as $clientType) {
            $clientType->translated_name = $clientType->translated_name;
        }
        
        return view('client.client-types.list', compact('clientTypes'));
    }

    public function store(Request $request)
    {
        $currentProjectId = auth()->user()->project_id;
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255|unique:client_types,name,NULL,id,project_id,' . $currentProjectId,
            'description' => 'nullable|string',
            'discount' => 'nullable|numeric|min:0|max:100',
            'status' => 'boolean'
        ], [
            'name.unique' => 'Тип клиента с таким названием уже существует в вашем проекте.'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Ошибка валидации',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $data = $request->all();
            
            // Добавляем цвет по умолчанию, если не указан
            if (empty($data['color'])) {
                $data['color'] = '#e5e7eb'; // Серый цвет по умолчанию
            }
            
            $clientType = ClientType::create($data + ['project_id' => $currentProjectId]);
            return response()->json([
                'success' => true,
                'message' => 'Тип клиента успешно создан',
                'clientType' => $clientType
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Ошибка при создании типа клиента: ' . $e->getMessage()
            ], 500);
        }
    }

    public function show($id)
    {
        $type = ClientType::with('clients')->findOrFail($id);
        return response()->json($type);
    }

    public function update(Request $request, $id)
    {
        $currentProjectId = auth()->user()->project_id;
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255|unique:client_types,name,' . $id . ',id,project_id,' . $currentProjectId,
            'description' => 'nullable|string',
            'discount' => 'nullable|numeric|min:0|max:100',
            'status' => 'boolean'
        ], [
            'name.unique' => 'Тип клиента с таким названием уже существует в вашем проекте.'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Ошибка валидации',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $clientType = ClientType::findOrFail($id);
            if ($clientType->is_global) {
                return response()->json([
                    'success' => false,
                    'message' => 'Этот тип клиента нельзя изменять и удалить, так как он системный.'
                ], 403);
            }
            $clientType->update($request->all());
            return response()->json([
                'success' => true,
                'message' => 'Тип клиента успешно обновлен',
                'clientType' => $clientType
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Ошибка при обновлении типа клиента: ' . $e->getMessage()
            ], 500);
        }
    }

    public function destroy($id)
    {
        try {
            $type = ClientType::findOrFail($id);
            if ($type->is_global) {
                return response()->json([
                    'success' => false,
                    'message' => 'Этот тип клиента нельзя изменять и удалить, так как он системный.'
                ], 403);
            }
            // Проверяем, есть ли клиенты с этим типом
            if ($type->clients()->count() > 0) {
                return response()->json([
                    'success' => false,
                    'message' => 'Невозможно удалить тип клиента, так как существуют клиенты с этим типом'
                ], 422);
            }
            $type->delete();
            return response()->json([
                'success' => true,
                'message' => 'Тип клиента успешно удален'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Ошибка при удалении типа клиента: ' . $e->getMessage()
            ], 500);
        }
    }

    public function edit($id)
    {
        $clientType = ClientType::findOrFail($id);
        return response()->json($clientType);
    }
}
